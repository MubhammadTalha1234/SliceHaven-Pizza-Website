// script.js

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        
        // Check if href is not just '#'
        if (targetId && targetId !== '#' && document.querySelector(targetId)) {
            const targetElement = document.querySelector(targetId);
            targetElement.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Select the scroll button
const scrollToTopBtn = document.getElementById('scrollToTop');

// Ensure the button exists before adding event listeners
if (scrollToTopBtn) {
    // Show or hide the button based on scroll position
    window.addEventListener('scroll', () => {
        if (window.scrollY > 200) {  // If scrolled down 200px, show button
            scrollToTopBtn.style.display = 'block';
        } else {
            scrollToTopBtn.style.display = 'none';
        }
    });

    // Smooth scrolling functionality when button is clicked
    scrollToTopBtn.addEventListener('click', (e) => {
        e.preventDefault();  // Prevent default anchor behavior
        window.scrollTo({
            top: 0,           // Scroll to the top of the page
            behavior: 'smooth' // Smooth scrolling effect
        });
    });
}
